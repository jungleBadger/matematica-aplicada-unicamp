<template>
  <section>
    <section>
      <h1>AI Services</h1>
    </section>

    <section
      data-background-size="cover"
      data-background-image="/static/pixelart2.webp"
      data-background-opacity="0.15"
    >
      <h1 class="header-title">Inference endpoints</h1>
      <p class="fragment">OpenAI APIs</p>
      <p class="fragment">Amazon Bedrock</p>
      <p class="fragment">IBM Watsonx.ai</p>
    </section>

    <section
      data-background-size="cover"
      data-background-image="/static/pixelart2.webp"
      data-background-opacity="0.15"
    >
      <h1 class="header-title">Models as a Service</h1>
      <p class="fragment">HuggingFace</p>
      <p class="fragment">Civitai</p>
      <p class="fragment">Kuki</p>
    </section>

    <section>
      Demo 1 - HuggingFace model exploration and Jupyter notebook integration
    </section>
    <section>Demo 2 - Query your Video solution architecture review</section>
    <section>Demo 3 - QA Generator solution architecture review</section>
  </section>
</template>
<script type="text/javascript">
"use strict";
import { defineComponent } from "vue";

export default defineComponent({
  name: "SectionAIEnablement",
  data: function () {
    return {};
  },
  components: {},
  computed: {},
  methods: {}
});
</script>
<style lang="scss" rel="stylesheet/scss" scoped></style>
