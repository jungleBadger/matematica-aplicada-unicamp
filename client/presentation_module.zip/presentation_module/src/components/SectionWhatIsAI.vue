<template>
  <section>
    <section
      data-background-size="cover"
      data-background-image="/static/pixelart5.webp"
      data-background-opacity="0.15"
    >
      <h1>What is AI?</h1>
    </section>

    <section
      data-background-size="cover"
      data-background-image="/static/pixelart5.webp"
      data-background-opacity="0.15"
      data-transition="concave"
    >
      <h2>but, first:</h2>
    </section>

    <section
      data-background-size="cover"
      data-background-image="/static/pixelart5.webp"
      data-background-opacity="0.15"
      data-transition="concave"
    >
      <h1>
        <span>What AI is not?</span>
      </h1>
    </section>

    <section
      data-transition="concave-in convex-out"
      data-background-size="cover"
      data-background-image="/static/pixelart5.webp"
      data-background-opacity="0.3"
      data-auto-animate
    >
      <p>Steal jobs</p>
    </section>

    <section
      data-transition="concave-in convex-out"
      data-background-size="cover"
      data-background-image="/static/pixelart5.webp"
      data-background-opacity="0.3"
      data-auto-animate
    >
      <p>Steal jobs</p>
      <p>Unsupervised learning</p>
    </section>

    <section
      data-transition="concave-in convex-out"
      data-background-size="cover"
      data-background-image="/static/pixelart5.webp"
      data-background-opacity="0.3"
      data-auto-animate
    >
      <p>Steal jobs</p>
      <p>Solve all the problems</p>
      <p>Unsupervised learning</p>
    </section>
    <section
      data-transition="concave-in convex-out"
      data-background-size="cover"
      data-background-image="/static/pixelart5.webp"
      data-background-opacity="0.3"
      data-auto-animate
    >
      <p>Steal jobs</p>
      <p style="color: #ffa500">Solve all the problems</p>
      <p>Unsupervised learning</p>
    </section>

    <section
      data-background-size="contain"
      data-background-image="/static/meme1.webp"
    ></section>

    <section>so...</section>

    <section
      data-transition="concave-in convex-out"
      data-background-size="cover"
      data-background-image="/static/pixelart6.webp"
      data-background-opacity="0.15"
    >
      <h1>
        <span>What is AI?</span>
      </h1>
    </section>

    <section
      data-transition="concave-in convex-out"
      data-background-size="cover"
      data-background-image="/static/pixelart6.webp"
      data-background-opacity="0.3"
    >
      <p>Augment skills</p>
      <p class="fragment">Reduce learning curve</p>
      <p class="fragment">Create complex solutions</p>
    </section>

    <section
      data-transition="concave-in convex-out"
      data-background-size="cover"
      data-background-image="/static/pixelart6.webp"
      data-background-opacity="0.3"
    >
      <h1>
        <span>What has changed?</span>
      </h1>
    </section>

    <section
      data-background-iframe="https://arxiv.org/pdf/1706.03762"
      data-background-interactive
    ></section>

    <section
      data-background-size="contain"
      data-background-image="/static/pixelart7.webp"
      data-background-opacity="0.15"
    >
      <h1>
        <span>Transformers Architecture</span>
      </h1>
      <p
        class="fragment"
        aria-label="Self-Attention: This mechanism allows the model to focus on different parts of the input simultaneously. Each word (or token) in a sequence can attend to every other word, making it easier to capture relationships regardless of their position in the sentence. This makes transformers highly effective for tasks involving long-range dependencies, such as translation or text summarization."
      >
        <span>Self-attention mechanism</span>
      </p>
      <p
        class="fragment"
        aria-label="Simplified Hyperparameters: The transformer architecture reduces the need for complex tuning, making it more efficient to train."
      >
        Simplified Hyperparameters
      </p>
      <p
        class="fragment"
        aria-label="Parallel Processing: Unlike traditional models that process sequences one step at a time (e.g., RNNs), transformers handle all input tokens in parallel. This significantly reduces the time needed for both training and inference, allowing transformers to scale efficiently to large datasets."
      >
        Parallel Processing
      </p>
    </section>

    <section
      data-background-size="contain"
      data-background-image="/static/pixelart7.webp"
      data-background-opacity="0.15"
    >
      <h1>
        <span>Translates to:</span>
      </h1>
      <p class="fragment">
        <span>Better understanding and general-task resolution</span>
      </p>
      <p class="fragment">
        <span>Simpler to configure and manage</span>
      </p>
      <p
        class="fragment"
        aria-label="Parallel Processing: Unlike traditional models that process sequences one step at a time (e.g., RNNs), transformers handle all input tokens in parallel. This significantly reduces the time needed for both training and inference, allowing transformers to scale efficiently to large datasets."
      >
        <span>Faster and cheaper training</span>
      </p>
    </section>

    <section
      data-background-size="contain"
      data-background-image="/static/pixelart7.webp"
      data-background-opacity="0.15"
    >
      <h1>
        <span>What has changed after all?</span>
      </h1>
      <p class="fragment">
        <span>New capabilities and solutions</span>
      </p>
      <p class="fragment">
        <span>Faster adoption and reduced learning curve</span>
      </p>
      <p
        class="fragment"
        aria-label="Parallel Processing: Unlike traditional models that process sequences one step at a time (e.g., RNNs), transformers handle all input tokens in parallel. This significantly reduces the time needed for both training and inference, allowing transformers to scale efficiently to large datasets."
      >
        <span>Decent user-facing performance</span>
      </p>
    </section>
  </section>
</template>
<script type="text/javascript">
"use strict";
import { defineComponent } from "vue";

export default defineComponent({
  name: "SectionWhatIsAI",
  data: function () {
    return {};
  },
  components: {},
  computed: {},
  methods: {}
});
</script>
<style lang="scss" rel="stylesheet/scss" scoped></style>
