<template>
  <section>
    <section>
      <h1>Personal Assistants</h1>
    </section>

    <section
      data-background-size="cover"
      data-background-image="/static/pixelart2.webp"
      data-background-opacity="0.15"
    >
      <h1 class="header-title">Voice assistants</h1>
      <p class="fragment">Amazon Alexa</p>
      <p class="fragment">Siri by Apple</p>
      <p class="fragment">Google Home Assistant</p>
    </section>

    <section
      data-background-size="cover"
      data-background-image="/static/pixelart2.webp"
      data-background-opacity="0.15"
    >
      <h1 class="header-title">UI-based assistants</h1>
      <p class="fragment">ChatGPT</p>
      <p class="fragment">Anthropic Claude</p>
      <p class="fragment">Google Gemini</p>
    </section>

    <section
      data-background-size="cover"
      data-background-image="/static/pixelart2.webp"
      data-background-opacity="0.15"
    >
      <h1 class="header-title">Code assistants</h1>
      <p class="fragment">GitHub CoPilot</p>
      <p class="fragment">Amazon Code Whisperer</p>
      <p class="fragment">JetBrains AI</p>
    </section>

    <section>Demo 1 - Creating UX Personas using ChatGPT</section>
    <section>
      Demo 2 - Theme extraction from an image and CSS template generation
    </section>
    <section>Demo 3 - Concept explanation</section>
  </section>
</template>
<script type="text/javascript">
"use strict";
import { defineComponent } from "vue";

export default defineComponent({
  name: "SectionPersonalAssistants",
  data: function () {
    return {};
  },
  components: {},
  computed: {},
  methods: {}
});
</script>
<style lang="scss" rel="stylesheet/scss" scoped></style>
